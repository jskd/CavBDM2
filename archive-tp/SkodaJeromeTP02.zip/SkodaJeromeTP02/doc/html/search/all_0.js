var searchData=
[
  ['1_2dnatural_2djoin_2ec',['1-natural-join.c',['../1-natural-join_8c.html',1,'']]]
];
