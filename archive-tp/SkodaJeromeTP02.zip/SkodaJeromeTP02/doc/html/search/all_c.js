var searchData=
[
  ['writebufferinfile',['writeBufferInFile',['../bdd_8c.html#a28b99b13e958fa0d0d034e10c1f40252',1,'writeBufferInFile(FILE *fp, const struct buf *buf):&#160;bdd.c'],['../bdd_8h.html#a28b99b13e958fa0d0d034e10c1f40252',1,'writeBufferInFile(FILE *fp, const struct buf *buf):&#160;bdd.c']]],
  ['writebufferinfileoc',['writeBufferInFileOC',['../bdd_8c.html#a106f6f28f7c6dee78e9666be1efa49ec',1,'writeBufferInFileOC(const char *file_name, const struct buf *buf):&#160;bdd.c'],['../bdd_8h.html#ac868457bc94326deb656db591c204d3d',1,'writeBufferInFileOC(const char *file_name, const struct buf *):&#160;bdd.c']]]
];
