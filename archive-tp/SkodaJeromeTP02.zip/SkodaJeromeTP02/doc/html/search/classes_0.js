var searchData=
[
  ['buf',['buf',['../structbuf.html',1,'']]]
];
