/**
* TP n°: 2
*
* Titre du TP : Merge Join
*
* Date : 13/10/17
*
* Nom : Lefranc
* Prenom : Joaquim
* email : lefrancjoaquim@gmail.com
*
* Nom : Skoda
* Prenom : Jérôme
* email : contact@jeromeskoda.fr
*
* Remarques :
*/

/* Remarques : Ce fichier a été récuprer du site:
*   https://stackoverflow.com/questions/7775991/how-to-get-hexdump-of-a-structure-data#7776146
*   il a été réadapté dans le cadre du projet
*/

void hexDump (char *desc, const void *addr, int len);
