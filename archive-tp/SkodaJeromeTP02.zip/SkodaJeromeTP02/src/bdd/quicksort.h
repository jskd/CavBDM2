/**
* TP n°: 2
*
* Titre du TP : Merge Join
*
* Date : 13/10/17
*
* Nom : Lefranc
* Prenom : Joaquim
* email : lefrancjoaquim@gmail.com
*
* Nom : Skoda
* Prenom : Jérôme
* email : contact@jeromeskoda.fr
*
* Remarques :
*/

/**
 * Remarques : Ce fichier a été récuprer du site:
 *   http://www.zentut.com/c-tutorial/c-quicksort-algorithm/
 *   il a été réadapté dans le cadre du projet
 */

void quicksort(char *list, char m, char n);
