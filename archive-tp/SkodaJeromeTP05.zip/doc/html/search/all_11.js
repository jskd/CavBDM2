var searchData=
[
  ['writebufferinfile',['writeBufferInFile',['../buffer_8c.html#aa3063a041f95609c8ac45636f5389f47',1,'writeBufferInFile(const char *file_name, const struct buf *buf):&#160;buffer.c'],['../buffer_8h.html#a53341b8f08d489b87d66f9dc1c61e8dc',1,'writeBufferInFile(const char *file_name, const struct buf *):&#160;buffer.c']]]
];
