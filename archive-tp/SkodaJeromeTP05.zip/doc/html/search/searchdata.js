var indexSectionsWithContent =
{
  0: "01_abcdhkmnpqrstvw",
  1: "bdh",
  2: "01bdhmnqrt",
  3: "bcdhmnpqsw",
  4: "cdkmsv",
  5: "_",
  6: "an"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

