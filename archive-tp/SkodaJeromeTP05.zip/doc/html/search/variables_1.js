var searchData=
[
  ['data_5fsize',['data_size',['../structbuffer.html#ae300700c0ded7673ce9872c86aa64383',1,'buffer']]]
];
