var searchData=
[
  ['s',['s',['../structbuf.html#aae0f7f61347b29fa0088cbf7d952b14c',1,'buf::s()'],['../structbuffer.html#aa214b7e2c7732822456c6201a95274e5',1,'buffer::s()'],['../structdisk.html#a9bf7ec366060578b4b3712e47b6b379b',1,'disk::s()']]]
];
