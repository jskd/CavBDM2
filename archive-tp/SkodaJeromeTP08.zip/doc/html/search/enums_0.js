var searchData=
[
  ['buffer_5ffile_5fmode',['buffer_file_mode',['../buffer_8h.html#abbc0d3ec153480799ecb51b5aed0b292',1,'buffer.h']]]
];
