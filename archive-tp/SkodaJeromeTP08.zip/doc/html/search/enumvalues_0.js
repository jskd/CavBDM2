var searchData=
[
  ['buffer_5fcharacters',['BUFFER_CHARACTERS',['../buffer_8h.html#abbc0d3ec153480799ecb51b5aed0b292a7f1613ba58a7869dc65bafcbe8fb154a',1,'buffer.h']]],
  ['buffer_5fdecimals',['BUFFER_DECIMALS',['../buffer_8h.html#abbc0d3ec153480799ecb51b5aed0b292aacb9eb99c25edcedef45a5d6d640acfe',1,'buffer.h']]]
];
