var searchData=
[
  ['rmrf',['rmrf',['../rmrf_8c.html#ac529675c8a1875f1ebc3054f8c4256c2',1,'rmrf(const char *path):&#160;rmrf.c'],['../rmrf_8h.html#ac529675c8a1875f1ebc3054f8c4256c2',1,'rmrf(const char *path):&#160;rmrf.c']]]
];
