var searchData=
[
  ['f',['f',['../structdiskReader.html#a17ad91ec85d74f653e3763ab171be675',1,'diskReader']]],
  ['f_5fcount',['f_count',['../structdiskReader.html#ace7c2f4dcf8c53fd63bd5109e82c1b3a',1,'diskReader']]],
  ['f_5fprefixe',['f_prefixe',['../structdiskManagerWriter.html#a816bb0d0340df458a311862bb326cc71',1,'diskManagerWriter']]],
  ['f_5fsuffixe',['f_suffixe',['../structdiskManagerWriter.html#aea8d9d76556366ae47ca7c79086260ca',1,'diskManagerWriter']]],
  ['file_5fnumber',['file_number',['../structdiskWriter.html#a4df2b272d625f2760023c9f1523a85ce',1,'diskWriter']]],
  ['fp',['fp',['../structdiskReader.html#a03d258827c72a9eb8a7e97975bd1c6ba',1,'diskReader']]]
];
