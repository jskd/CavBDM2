var searchData=
[
  ['read_5fcounter',['read_counter',['../structbuffer.html#ac27b1afa7036b24d179515af586eed08',1,'buffer']]],
  ['rfile_5fcounter',['rfile_counter',['../structbuffer.html#a092c37f0f059abd40871fdb6ccb1ac21',1,'buffer']]]
];
