var searchData=
[
  ['wfile_5fcounter',['wfile_counter',['../structbuffer.html#a24c096078427473138016ef146f1b1d3',1,'buffer']]],
  ['write_5fcounter',['write_counter',['../structbuffer.html#a299e4c4acc3929d3faf6b11e286a8607',1,'buffer::write_counter()'],['../structtable.html#a0606abffe192d234f7de607354f2addf',1,'table::write_counter()']]]
];
