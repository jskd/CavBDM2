/**
* TP n°: 3
*
* Titre du TP : Merge Join Duplicate
*
* Date : 21/10/17
*
* Nom : Lefranc
* Prenom : Joaquim
* email : lefrancjoaquim@gmail.com
*
* Nom : Skoda
* Prenom : Jérôme
* email : contact@jeromeskoda.fr
*
* Remarques :
*/

#ifndef SRC_BDD_QUICKSORT_H
#define SRC_BDD_QUICKSORT_H

/**
 * Remarques : Ce fichier a été récuprer du site:
 *   http://www.zentut.com/c-tutorial/c-quicksort-algorithm/
 *   il a été réadapté dans le cadre du projet
 */

void quicksort(char *list, char m, char n);

#endif
