var searchData=
[
  ['1_2dnatural_2djoin_2d1_2ec',['1-natural-join-1.c',['../1-natural-join-1_8c.html',1,'']]]
];
