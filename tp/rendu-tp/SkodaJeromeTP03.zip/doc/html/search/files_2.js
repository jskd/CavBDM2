var searchData=
[
  ['2_2dnatural_2djoin_2d2_2ec',['2-natural-join-2.c',['../2-natural-join-2_8c.html',1,'']]]
];
