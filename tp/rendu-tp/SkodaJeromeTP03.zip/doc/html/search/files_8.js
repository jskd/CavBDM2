var searchData=
[
  ['buffer_2ec',['buffer.c',['../buffer_8c.html',1,'']]],
  ['buffer_2eh',['buffer.h',['../buffer_8h.html',1,'']]]
];
