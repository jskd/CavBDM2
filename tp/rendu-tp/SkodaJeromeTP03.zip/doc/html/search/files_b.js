var searchData=
[
  ['naturaljoin_2ec',['naturalJoin.c',['../naturalJoin_8c.html',1,'']]],
  ['naturaljoin_2eh',['naturalJoin.h',['../naturalJoin_8h.html',1,'']]]
];
