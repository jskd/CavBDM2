var indexSectionsWithContent =
{
  0: "01234567abchmnqrstvw",
  1: "b",
  2: "01234567bhmnqrt",
  3: "bchmnqsw",
  4: "csv",
  5: "an"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Pages"
};

