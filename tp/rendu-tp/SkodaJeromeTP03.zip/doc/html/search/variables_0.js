var searchData=
[
  ['c',['c',['../structbuf.html#a37cf76bb775bf17b3e7566e0611428e6',1,'buf']]]
];
