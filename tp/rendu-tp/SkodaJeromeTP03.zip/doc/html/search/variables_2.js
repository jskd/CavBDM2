var searchData=
[
  ['v',['v',['../structbuf.html#a0690d33ca270683cb07fd9a1b9f4dd68',1,'buf']]]
];
