var searchData=
[
  ['data_5fsize',['data_size',['../structbuffer.html#ae300700c0ded7673ce9872c86aa64383',1,'buffer']]],
  ['disk',['disk',['../structdisk.html',1,'']]],
  ['disk_2ec',['disk.c',['../disk_8c.html',1,'']]],
  ['disk_2eh',['disk.h',['../disk_8h.html',1,'']]],
  ['disk_5fcount',['disk_count',['../disk_8c.html#a396bc7b473fcac3c621cd07601438984',1,'disk_count(const struct disk *disk):&#160;disk.c'],['../disk_8h.html#a396bc7b473fcac3c621cd07601438984',1,'disk_count(const struct disk *disk):&#160;disk.c']]],
  ['disk_5fcreate',['disk_create',['../disk_8c.html#aea35e7fb078fe89ecda9b6e8be7cf5e2',1,'disk_create(const char *dir, const char *mode):&#160;disk.c'],['../disk_8h.html#aea35e7fb078fe89ecda9b6e8be7cf5e2',1,'disk_create(const char *dir, const char *mode):&#160;disk.c']]],
  ['disk_5fdestroy',['disk_destroy',['../disk_8c.html#a26874909c88afc0a0b3b4bb0415d02c1',1,'disk_destroy(struct disk *disk):&#160;disk.c'],['../disk_8h.html#a26874909c88afc0a0b3b4bb0415d02c1',1,'disk_destroy(struct disk *disk):&#160;disk.c']]],
  ['disk_5fitem',['disk_item',['../disk_8c.html#ad478269d43146ae1398410db10e9b729',1,'disk_item(const struct disk *disk, int index):&#160;disk.c'],['../disk_8h.html#ad478269d43146ae1398410db10e9b729',1,'disk_item(const struct disk *disk, int index):&#160;disk.c']]]
];
