var searchData=
[
  ['navigation',['Navigation',['../md_src_README.html',1,'']]],
  ['natural_5fjoin',['natural_join',['../nestedLoopJoin_8c.html#aba4fdc593d424a1149e07a923012ff5b',1,'natural_join(const struct buffer *buf_a, const struct buffer *buf_b, struct buffer *buf_out):&#160;nestedLoopJoin.c'],['../nestedLoopJoin_8h.html#aba4fdc593d424a1149e07a923012ff5b',1,'natural_join(const struct buffer *buf_a, const struct buffer *buf_b, struct buffer *buf_out):&#160;nestedLoopJoin.c']]],
  ['nested_5floop_5fjoin',['nested_loop_join',['../nestedLoopJoin_8c.html#abf3e20fd47c9220493e55510f70257d9',1,'nested_loop_join(const struct buffer *buf_a, const struct buffer *buf_b, struct buffer *buf_out, FILE *overflow_file):&#160;nestedLoopJoin.c'],['../nestedLoopJoin_8h.html#abf3e20fd47c9220493e55510f70257d9',1,'nested_loop_join(const struct buffer *buf_a, const struct buffer *buf_b, struct buffer *buf_out, FILE *overflow_file):&#160;nestedLoopJoin.c']]],
  ['nested_5floop_5fjoin_5fdisk',['nested_loop_join_disk',['../nestedLoopJoin_8c.html#a7be28984d047552d99b9ccc2cf380db9',1,'nested_loop_join_disk(const struct disk *disk_a, struct buffer *buf_a, const struct disk *disk_b, struct buffer *buf_b, struct buffer *buf_out, FILE *overflow_file):&#160;nestedLoopJoin.c'],['../nestedLoopJoin_8h.html#a7be28984d047552d99b9ccc2cf380db9',1,'nested_loop_join_disk(const struct disk *disk_a, struct buffer *buf_a, const struct disk *disk_b, struct buffer *buf_b, struct buffer *buf_out, FILE *overflow_file):&#160;nestedLoopJoin.c']]],
  ['nestedloopjoin_2ec',['nestedLoopJoin.c',['../nestedLoopJoin_8c.html',1,'']]],
  ['nestedloopjoin_2eh',['nestedLoopJoin.h',['../nestedLoopJoin_8h.html',1,'']]]
];
