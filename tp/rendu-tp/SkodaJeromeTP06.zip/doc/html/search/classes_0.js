var searchData=
[
  ['buf',['buf',['../structbuf.html',1,'']]],
  ['buffer',['buffer',['../structbuffer.html',1,'']]]
];
